interface Props {
  label?: string;
  className?: string;
  symbol?: "diamond" | "lotus" | "dot";
}

export default function OrnamentalDivider({ label, className = "", symbol = "diamond" }: Props) {
  const sym = symbol === "lotus" ? "❋" : symbol === "dot" ? "·" : "◆";

  return (
    <div className={`flex items-center gap-4 ${className}`}>
      <div className="flex-1 ornament-line" />
      {label ? (
        <span className="section-label whitespace-nowrap">{label}</span>
      ) : (
        <span className="text-accent text-[8px] opacity-50">{sym}</span>
      )}
      <div className="flex-1 ornament-line" />
    </div>
  );
}
