import { useState, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { SlidersHorizontal, X, ChevronDown } from "lucide-react";
import { mainProducts } from "@/data/products";
import { deities, allChakras, allElements, matchProductToDeity } from "@/data/deities";
import ProductCard from "@/components/ProductCard";
import OrnamentalDivider from "@/components/OrnamentalDivider";

export default function Collection() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialDeity = searchParams.get("deity") || "";
  const [selectedDeity, setSelectedDeity] = useState(initialDeity);
  const [selectedChakra, setSelectedChakra] = useState("");
  const [selectedElement, setSelectedElement] = useState("");
  const [showMoreFilters, setShowMoreFilters] = useState(false);
  const [sortBy, setSortBy] = useState<"default" | "price-asc" | "price-desc">("default");

  // Get unique deities from products
  const productDeities = useMemo(() => {
    const names = new Set<string>();
    mainProducts.forEach((p) => {
      const d = matchProductToDeity(p.title);
      if (d) names.add(d.name);
    });
    return Array.from(names);
  }, []);

  const filtered = useMemo(() => {
    let results = mainProducts;

    if (selectedDeity) {
      results = results.filter((p) => {
        const d = matchProductToDeity(p.title);
        return d?.name === selectedDeity;
      });
    }
    if (selectedChakra) {
      results = results.filter((p) =>
        p.tags.some((t) => t.startsWith("chakra:") && t.includes(selectedChakra))
      );
    }
    if (selectedElement) {
      results = results.filter((p) =>
        p.tags.some((t) => t === `element:${selectedElement}`)
      );
    }

    if (sortBy === "price-asc") {
      results = [...results].sort((a, b) => a.variants[0].priceINR - b.variants[0].priceINR);
    } else if (sortBy === "price-desc") {
      results = [...results].sort((a, b) => b.variants[0].priceINR - a.variants[0].priceINR);
    }

    return results;
  }, [selectedDeity, selectedChakra, selectedElement, sortBy]);

  function clearFilters() {
    setSelectedDeity("");
    setSelectedChakra("");
    setSelectedElement("");
    setSearchParams({});
  }

  function selectDeity(name: string) {
    const next = selectedDeity === name ? "" : name;
    setSelectedDeity(next);
    if (next) {
      setSearchParams({ deity: next });
    } else {
      setSearchParams({});
    }
  }

  const hasActiveFilters = selectedDeity || selectedChakra || selectedElement;

  return (
    <div className="bg-surface min-h-screen">
      {/* Header */}
      <section className="section-b border-b border-border py-10">
        <div className="max-w-[1400px] mx-auto px-6 text-center">
          <p className="section-label mb-2">The Collection</p>
          <h1 className="font-display text-4xl md:text-5xl text-on-surface font-light">
            Sacred Forms
          </h1>
          <p className="font-body text-sm text-on-surface-faint mt-3 max-w-md mx-auto">
            Hand-cast brass deity murtis from Haridwar. Each form chosen with intention.
          </p>
        </div>
      </section>

      {/* Sticky filter bar */}
      <div className="sticky top-16 z-40 bg-surface/95 backdrop-blur-md border-b border-border">
        <div className="max-w-[1400px] mx-auto px-6 py-4">
          {/* Deity buttons — always visible */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-body text-[10px] tracking-wider uppercase text-on-surface-faint mr-2">Deity:</span>
            {productDeities.map((name) => (
              <button
                key={name}
                onClick={() => selectDeity(name)}
                className={selectedDeity === name ? "filter-chip-active" : "filter-chip"}
              >
                {name}
              </button>
            ))}

            <div className="ml-auto flex items-center gap-3">
              {/* More Filters toggle */}
              <button
                onClick={() => setShowMoreFilters(!showMoreFilters)}
                className={`flex items-center gap-1.5 font-body text-xs tracking-wider transition-colors ${
                  showMoreFilters || selectedChakra || selectedElement
                    ? "text-accent"
                    : "text-on-surface-faint hover:text-on-surface-muted"
                }`}
              >
                <SlidersHorizontal size={14} />
                More Filters
                <ChevronDown size={12} className={`transition-transform ${showMoreFilters ? "rotate-180" : ""}`} />
              </button>

              {/* Sort */}
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                className="font-body text-xs bg-transparent text-on-surface-faint border border-border rounded-md px-3 py-1.5 focus:outline-none focus:border-accent"
              >
                <option value="default">Default</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
              </select>
            </div>
          </div>

          {/* More filters — expandable */}
          <AnimatePresence>
            {showMoreFilters && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden"
              >
                <div className="pt-4 flex flex-col sm:flex-row gap-4">
                  {/* Chakra filter */}
                  <div>
                    <span className="font-body text-[10px] tracking-wider uppercase text-on-surface-faint block mb-2">
                      Chakra
                    </span>
                    <div className="flex gap-2 flex-wrap">
                      {allChakras.map((c) => (
                        <button
                          key={c.key}
                          onClick={() => setSelectedChakra(selectedChakra === c.key ? "" : c.key)}
                          className={selectedChakra === c.key ? "filter-chip-active" : "filter-chip"}
                        >
                          {c.name.split(" (")[0]}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Element filter */}
                  <div>
                    <span className="font-body text-[10px] tracking-wider uppercase text-on-surface-faint block mb-2">
                      Element
                    </span>
                    <div className="flex gap-2 flex-wrap">
                      {allElements.map((el) => (
                        <button
                          key={el}
                          onClick={() => setSelectedElement(selectedElement === el ? "" : el)}
                          className={selectedElement === el ? "filter-chip-active" : "filter-chip"}
                        >
                          {el}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Active filter chips */}
          {hasActiveFilters && (
            <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border/50">
              {selectedDeity && (
                <span className="filter-chip-active flex items-center gap-1.5">
                  {selectedDeity}
                  <button onClick={() => selectDeity("")}><X size={10} /></button>
                </span>
              )}
              {selectedChakra && (
                <span className="filter-chip-active flex items-center gap-1.5">
                  {allChakras.find(c => c.key === selectedChakra)?.name.split(" (")[0]}
                  <button onClick={() => setSelectedChakra("")}><X size={10} /></button>
                </span>
              )}
              {selectedElement && (
                <span className="filter-chip-active flex items-center gap-1.5">
                  {selectedElement}
                  <button onClick={() => setSelectedElement("")}><X size={10} /></button>
                </span>
              )}
              <button
                onClick={clearFilters}
                className="font-body text-[10px] text-on-surface-faint hover:text-accent ml-2 tracking-wider uppercase"
              >
                Clear All
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Product grid */}
      <section className="py-12 bg-grain">
        <div className="max-w-[1400px] mx-auto px-6">
          <p className="font-body text-xs text-on-surface-faint mb-6">
            {filtered.length} {filtered.length === 1 ? "form" : "forms"} found
          </p>

          {filtered.length === 0 ? (
            <div className="text-center py-20">
              <p className="font-display text-2xl text-on-surface-faint mb-3">No forms match your filters</p>
              <button onClick={clearFilters} className="btn-outline">
                Clear Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
              {filtered.map((p, i) => (
                <ProductCard key={p.id} product={p} index={i} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
